import React from 'react';

const AddDraftDocument = () => {
    return (<>
    </>);
}



export default AddDraftDocument;