import React from 'react';

const ProfileEdit = () => {
    return (<>
    
    
    
    </>);
}

export default ProfileEdit;